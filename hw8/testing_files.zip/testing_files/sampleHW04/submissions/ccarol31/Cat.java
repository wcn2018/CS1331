//I worked on the home work assignment alone, using only course materials.
/**
 * @author Carol Carol
 * @version 1.0 Mar 05, 19
 **/
public class Cat {
    int livesLeft;
    String name;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public int getLivesLeft() {
        return livesLeft;
    }

    public void setLivesLeft(int livesLeft) {
        this.livesLeft = livesLeft;
    }
}
