//I worked on the homework assignment alone, using only course materials.
/**
 * @author Bob Bob
 * @version 1.0 Mar 05, 19
 **/
public class Cat {
    private int livesLeft;
    private String nam;
}
