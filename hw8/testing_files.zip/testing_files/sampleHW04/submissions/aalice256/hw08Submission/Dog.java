/**
 * @author Bob Bob
 * @version 1.0 Mar 05, 19
 **/
public class Dog {
    private String name;
    private boolean isAGoodBoy;
}
