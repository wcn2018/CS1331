//i worked on the homework assignment ALONE, using only course materials.
/**
 * @author Eve Eve
 * @version 1.0 Mar 05, 19
 **/
public class Dog {
    private String name;
    private boolean isAGoodBoy;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public boolean getIsAGoodBoy() {
        return isAGoodBoy;
    }

    public void setIsAGoodBoy(boolean isAGoodBoy) {
        this.isAGoodBoy = isAGoodBoy;
    }
}
