/**
 * @author Eve Eve
 * @version 1.0 Mar 05, 19
 **/
public class Cat {
    private int livesLeft;
    private String name;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public int getLivesLeft() {
        return livesLeft;
    }

    public void setLivesLeft(int livesLeft) {
        this.livesLeft = livesLeft;
    }
}
